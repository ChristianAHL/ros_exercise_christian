#!/usr/bin/env python
"""
Script that generates a node that has a subscriber to the topic 'print_out'.
Script prints out arguments received from the topic 'print_out', similar to echoing the
'print_out' topic.
"""

import rospy
from std_msgs.msg import String

def callback(data):
    rospy.loginfo(f"From topic /print_out: {data.data}")

def print_out_subscriber():

    rospy.init_node('print_out', anonymous=True)
    rospy.Subscriber('print_out', String, callback)

    rospy.spin()

if __name__ == '__main__':
    print("Ready to receive messages from topic /print_out.")
    print_out_subscriber()
