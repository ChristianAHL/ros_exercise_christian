#!/usr/bin/env python
"""
Script that generates a node to handle 'call_capital' service requests.
Returns the capital city of a country based on data in 'country_data.json'.
"""

from beginner_tutorials.srv import CallCapital
import json
import rospy
import rospkg
from std_msgs.msg import String

def deserialize_json_file(filename):
    # TODO Consider refactoring to a common script that can be used across different scripts.
    """Deserialize json file 'filename' into Python dictionary 'deserialized_data'."""
    
    with open(filename) as f:
        deserialized_data = json.load(f)
        
    return deserialized_data

def publish_to_topic(topic_name, message): 
    # TODO Consider refactoring to a common script that can be used across different scripts.
    """"Publishes 'message' to ROS topic 'topic_name'. """
    
    pub = rospy.Publisher(topic_name, String, queue_size=10) # Initialize publisher
    rospy.sleep(1) # Added this delay to ensure that the first published message can be read by subscribers
    publish_str = str(message)
    rospy.loginfo(publish_str)
    pub.publish(publish_str)

    return None

def handle_call_capital(country_name):
    """Handle the 'call_capital' service."""
    
    try:
        
        # Python scripts when run on ROS are not run from the scripts folder.
        # Enables the script to find the 'country_data.json' file regardless of the 'plen_challenge_christian' package location.
        rospack = rospkg.RosPack()
        package_location = rospack.get_path('plen_challenge_christian')
        country_data_file_location = package_location + "/scripts/country_data.json"
        # Deserialize country_data.json
        country_data_deserialized = deserialize_json_file(country_data_file_location)

        # Do not include quotation marks and data name appended by .srv when looking it up in country_data_deserialized.
        country_name_request = (str(country_name)[15:-1]).strip() 
        
        # Acknowledge argument received 'country_name', find that country's capital city. Return and publish its capital city.
        print(f"Received capital city name request for {country_name_request}")
        country_capital_name = country_data_deserialized[country_name_request]['Capital']
        print(f"Returning {country_capital_name}")
        
        # Publish country_capital_name to topic print_out.
        publish_to_topic('print_out', country_capital_name)
        print("Ready to receive country name.")
        return country_capital_name
    
    # Handle the exception when country requested by user is not in 'country_data.json'.
    except KeyError:
        print(f"ERROR: The country {country_name_request} could not be found in country_data.json. Could not get country's capital.")
        print("Waiting to receive new country name.")
        country_capital_name = "Unknown"
        publish_to_topic('print_out', f'{country_name} could not be found. Capital city cannot be determined.')
        
        return country_capital_name

def call_capital_server():
    """Initialize the 'call_capital_server' node and 'call_capital' service."""
    rospy.init_node('call_capital_server')
    
    # Declare a service called call_capital
    # With the CallCapital service type
    # Requests are passed to handle_call_capital function.
    s = rospy.Service('call_capital', CallCapital, handle_call_capital)
    
    print("Ready to receive country name.")
    
    rospy.spin()
    
if __name__ == "__main__":
    
    call_capital_server()
