#! /usr/bin/env python
"""
Script that generates a node to handle 'call_motion' action requests.
Utilizes actionlib to handle actions.
Returns the frames contained in a specified motion file path.
"""

import rospy
import actionlib
import actionlib_tutorials.msg
import json
from std_msgs.msg import String

def deserialize_json_file(filename):
    # TODO Consider refactoring to a common script that can be used across different scripts.
    """Deserialize json file 'filename' into Python dictionary 'deserialized_data'."""
    
    with open(filename) as f:
        deserialized_data = json.load(f)
        
    return deserialized_data

def publish_to_topic(topic_name, message): 
    # TODO Consider refactoring to a common script that can be used across different scripts.
    """"Publishes 'message' to ROS topic 'topic_name'. """
    
    pub = rospy.Publisher(topic_name, String, queue_size=10) # Initialize publisher
    rospy.sleep(1) # Added this delay to ensure that the first published message can be read by subscribers
    publish_str = str(message)
    rospy.loginfo(publish_str)
    pub.publish(publish_str)

    return None

class CallMotionAction(object):
    """Class to handle the 'call_motion' action."""
    # Create messages that are used to publish feedback/result
    _feedback = actionlib_tutorials.msg.CallMotionFeedback()
    _result = actionlib_tutorials.msg.CallMotionResult()

    def __init__(self, name):
        self._action_name = name
        self._as = actionlib.SimpleActionServer(self._action_name, actionlib_tutorials.msg.CallMotionAction, execute_cb=self.execute_cb, auto_start = False)
        self._as.start()
      
    def execute_cb(self, goal):
        
        r = rospy.Rate(1)
        

        # Feedback and result initialization.
        self._feedback.frame_data = ""
        all_frame_data_list = []
        
        # Publish info to the console for the user.
        rospy.loginfo('%s: Executing, extracting motion frames from path %s' % (self._action_name, goal.motion_file_path))
        
        # Start executing the action.
        try:
            motion_data_deserialized = deserialize_json_file(goal.motion_file_path)
        
            # Iterate through frames and return each frame's outputs and transition time data.
            for frame in motion_data_deserialized['frames']:
                print(f"\nINDEX: {frame['@index']}")

                # Parse the deserialized data and format into required format. handle as string, action messages cannot take dictionaries.
                converted_frame_str = "{"

                for output in frame["outputs"]:
                    converted_frame_str = converted_frame_str + (f"'{output['device']}':{output['value']}, ")

                converted_frame_str = converted_frame_str + (f"'transition_time_ms':{frame['transition_time_ms']}")
                converted_frame_str = converted_frame_str + "}"
                
                print(converted_frame_str)

                # check if pre-empted
                if self._as.is_preempt_requested():
                    rospy.loginfo('%s: Preempted' % self._action_name)
                    self._as.set_preempted()
                    success = False
                    break

                self._feedback.frame_data = converted_frame_str
                
                # Publish the feedback
                self._as.publish_feedback(self._feedback)

                # Append frame to list of all frames read for results summary
                all_frame_data_list.append(self._feedback.frame_data) 
                
                # Publish frame/feedback to topic /print_out
                publish_to_topic('print_out', converted_frame_str)

                r.sleep()

            success = True

        except FileNotFoundError: # Handle the exception where motion file does not exist in argument path.
            publish_to_topic('print_out', f'{goal.motion_file_path} could not be found. No frames can be extracted.')

            success = False

        if success: # Check if action is successful.
                self._result.all_frame_data = all_frame_data_list
                rospy.loginfo('%s: Succeeded' % self._action_name)
                self._as.set_succeeded(self._result)

        elif not success:
            self._result.all_frame_data = all_frame_data_list
            rospy.loginfo('%s: Failed' % self._action_name)
            self._as.set_aborted(self._result)

        print("Ready to receive motion file path.")


if __name__ == '__main__':  
    rospy.init_node('call_motion')
    server = CallMotionAction(rospy.get_name())
    print("Ready to receive motion file path.")
    rospy.spin()

